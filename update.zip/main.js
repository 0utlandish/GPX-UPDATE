// Modules to control application life and create native browser window
const { app, Menu, Tray, BrowserWindow, ipcMain, globalShortcut, Notification } = require('electron');
const path = require('path');
const fs = require('fs');
const fsp = require('fs').promises;
const md5 = require('md5');
const { create } = require('domain');
const child_process = require('child_process');
const AutoLaunch = require('auto-launch');

require('@electron/remote/main').initialize();

let myWindow = null;
const gotTheLock = app.requestSingleInstanceLock();

let mainWindow, tray;

let templateHashCache;

function checkFileExists(s) {
  return new Promise(r => fs.access(s, fs.constants.F_OK, e => r(!e)));
}

function notify(title, message, icon = 'favicon.ico', callback = e => {}) {
  const notification = new Notification({ title, body: message, icon });
  notification.show();
  notification.on('click', (event, arg)=>{
    child_process.exec(`explorer.exe "${settings.data.cache['-gppFolder']}"`);
  });
}

async function generate(trace) {
  const template = await fsp.readFile("template.gpp", "utf-8");
  let patch = '';
  const cache = settings.data.cache;
  Object.keys(cache).forEach((variable, i) => {
    if (variable[0] === '-') return;
    if (trace !== undefined && variable === 'GPX_TRACE') {
      patch += (i > 0 ? '\t' : '') + `${variable} = ${trace}\n`;
    } else {
      patch += (i > 0 ? '\t' : '') + `${variable} = ${cache[variable]}\n`;
    }
  });
  fs.writeFileSync(path.join(settings.data.cache['-gppFolder'], settings.data.cache['-gppFileName']), template.replace('[-DATA-]', patch));
  mainWindow.webContents.send('gpp-synced');
  notify('Update', `GPP file synced [${(trace || cache['GPX_TRACE'])}]`);
}

const settings = {
  data: {
    cache: {},
    preferences: {},
  },
  init: async () => {
    await settings.create();
    settings.data = await settings.read();
  },
  create: () => {
    return new Promise((resolve, reject) => {
      checkFileExists("settings.json")
        .then(bool => {
          if (bool) {
            resolve();
            return;
          }
          fs.writeFile('settings.json', JSON.stringify({
            cache: {},
            preferences: {
              watchTemplate: true
            }
          }), function (err) {
            if (err) reject(err);
            resolve();
          });
        });
    });
  },
  read: () => {
    return new Promise((resolve, reject) => {
      fs.readFile('settings.json', "utf8", (err, data) => {
        resolve(JSON.parse(data));
      });
    });
  },
  write: () => {
    return new Promise((resolve, reject) => {
      fs.writeFile('settings.json', JSON.stringify(settings.data, null, '\t'), function (err) {
        if (err) reject(err);
        resolve();
      });
    });
  },
  setCache: async (newCache) => {
    settings.data.cache = newCache;
    await settings.write();
  },
  setPreference: async (preference, value) => {
    settings.data.preferences[preference] = value;
    await settings.write();
  }
}

const presets = {
  init: () => {
    return new Promise((resolve, reject) => {
      if (!fs.existsSync('presets')) {
        fs.mkdir('presets', (err) => {
          if (err) {
            reject(err);
            return;
          }
          resolve();
        });
      }
      resolve();
    });
  },
  list: () => {
    return new Promise((resolve, reject) => {
      fs.readdir('presets', (err, files) => {
        if (err) {
          reject();
          return;
        }
        resolve(files.sort(function (a, b) { return fs.statSync('./presets/' + a).mtime.getTime() - fs.statSync('./presets/' + b).mtime.getTime(); }).map(a => a.replace('.json', '')));
      });
    });
  },
  read: (preset) => {
    return new Promise((resolve, reject) => {
      fs.readFile(`./presets/${preset}.json`, "utf8", (err, data) => {
        if (err) {
          reject();
          return;
        }
        resolve(JSON.parse(data));
      });
    });
  },
  add: (preset, data) => {
    return new Promise((resolve, reject) => {
      fs.writeFile(`./presets/${preset}.json`, JSON.stringify(data, null, '\t'), function (err) {
        if (err) {
          reject();
          return;
        }
        resolve();
      });
    });
  },
  delete: (preset) => {
    return new Promise((resolve, reject) => {
      fs.unlink(`./presets/${preset}.json`, (err) => {
        if (err) {
          reject(err);
          return;
        }
        resolve();
      });
    });
  }
}

async function main() {
  await settings.init();
  await presets.init();

  function createWindow() {
    app.isQuiting = false;
    mainWindow = new BrowserWindow({
      width: 600,
      height: 700,
      resizable: false,
      frame: false,
      transparent: true,
      webPreferences: {
        icon: path.join(__dirname, 'favicon.ico'),
        preload: path.join(__dirname, 'preload.js'),
        nodeIntegration: true,
        contextIsolation: false,
        enableRemoteModule: true
      }
    });
    // mainWindow.webContents.openDevTools();
    tray = new Tray('favicon.ico');
    tray.on('double-click', () => {
      mainWindow.show();
    });
    const contextMenu = Menu.buildFromTemplate([
      {
        label: 'Auto Update GPP',
        type: 'checkbox',
        click: (e) => {
          settings.setPreference('watchTemplate', e.checked);
        },
        checked: settings.data?.preferences?.watchTemplate
      },
      {
        type: 'separator'
      },
      {
        label: 'Show',
        type: 'normal',
        click: () => {
          mainWindow.show();
        }
      },
      {
        label: 'Exit',
        type: 'normal',
        click: () => {
          app.isQuiting = true;
          app.quit();
        }
      },
    ]);
    tray.setToolTip('GPP Pre Processor');
    tray.setContextMenu(contextMenu);
    mainWindow.on('close', function (event) {
      if (app.isQuiting != true)
        event.preventDefault();
      mainWindow.hide();
    });
    mainWindow.on('minimize', function (event) {
      event.preventDefault();
      mainWindow.hide();
    });
    require('@electron/remote/main').enable(mainWindow.webContents);
    mainWindow.removeMenu();
    mainWindow.loadFile('index.html');
  }
  // prevent opening app more than once
  if (!gotTheLock) {
    app.quit()
  } else {
    app.on('window-all-closed', function () {
      if (process.platform !== 'darwin') app.quit()
    });
    app.on('second-instance', (event, commandLine, workingDirectory) => {
      if (myWindow) {
        if (myWindow.isMinimized()) myWindow.restore()
        myWindow.focus()
      }
    });
    app.whenReady().then(() => {
      if (process.platform === 'win32') {
        app.setAppUserModelId(process.execPath);
      }
      createWindow();
      app.on('activate', function () {
        if (BrowserWindow.getAllWindows().length === 0) createWindow()
      });
      globalShortcut.register('CommandOrControl+Alt+F5', () => {
        generate(5);
      });
      globalShortcut.register('CommandOrControl+Alt+F1', () => {
        generate(1);
      });
      globalShortcut.register('CommandOrControl+Alt+G', () => {
        mainWindow.show();
      });
      globalShortcut.register('CommandOrControl+Alt+Enter', () => {
        generate();
      });
    });
  }
  // update output gpp when template
  fs.watch("template.gpp", async function () {
    const template = await fsp.readFile('template.gpp', 'utf-8');
    const templateHash = md5(template);
    if (templateHash != templateHashCache) {
      templateHashCache = templateHash;
      mainWindow.webContents.send('gpp-not-synced');
      if (settings.data.preferences.watchTemplate)
        generate();
    }
  });
  ipcMain.on('get-presets', async () => {
    mainWindow.webContents.send('update-presets', await presets.list());
  });
  ipcMain.on('get-cache', async () => {
    mainWindow.webContents.send('update-cache', settings.data.cache);
  });
  ipcMain.on('get-presets-and-cache', async () => {
    mainWindow.webContents.send('update-presets', await presets.list());
    mainWindow.webContents.send('update-cache', settings.data.cache);
  });
  ipcMain.on('save-to-cache', async (_, newCache) => {
    settings.setCache(newCache);
  });
  ipcMain.on('add-preset', async (_, preset) => {
    await presets.add(preset.name, preset.data);
    mainWindow.webContents.send('update-presets', await presets.list());
  });
  ipcMain.on('delete-preset', async (_, name) => {
    await presets.delete(name);
    mainWindow.webContents.send('update-presets', await presets.list());
  });
  ipcMain.on('import-preset', async (_, name) => {
    settings.setCache(await presets.read(name));
    mainWindow.webContents.send('update-cache', settings.data.cache);
  });
  ipcMain.on('update-gpp', async (e) => {
    generate();
  });
}; main();