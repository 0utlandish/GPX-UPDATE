
const { ipcRenderer } = require("electron");
const remote = require('@electron/remote');
const fs = require('fs');
const request = require('request');
const admzip = require("adm-zip");
const dialog = remote.dialog;
const app = remote.app;

const title = 'GPP Pre Processor';

const download = (url, dest, cb) => {
   const file = fs.createWriteStream(dest);
   const sendReq = request.get(url, {
      'headers': {
         'Cache-Control': 'private, no-cache, no-store, must-revalidate, max-age=0',
         'Pragma': 'no-cache'
      }
   });
   sendReq.on('response', (response) => {
      if (response.statusCode !== 200) {
         return cb('Response status was ' + response.statusCode);
      }
      sendReq.pipe(file);
   });
   file.on('finish', () => file.close(cb));
   sendReq.on('error', (err) => {
      fs.unlink(dest);
      return cb(err.message);
   });
   file.on('error', (err) => {
      fs.unlink(dest);
      return cb(err.message);
   });
};

window.alert = function (str, type = 'warning') {
   var options = {
      type,
      buttons: ["Ok"],
      defaultId: 0,
      cancelId: 0,
      detail: str,
      message: ''
   }
   dialog.showMessageBoxSync(null, options)
}

alert('new pfffffsss !');

window.confirm = function (message, buttonLabel = 'OK') {
   const buttonIdx = remote.dialog.showMessageBoxSync(null, {
      type: 'question',
      buttons: [buttonLabel, 'Cancel'],
      defaultId: 0,
      cancelId: 1,
      detail: message,
      message: '',
   });
   return buttonIdx === 0;
};

ipcRenderer.send('get-presets-and-cache');

// update presets
ipcRenderer.on('update-presets', (_, presets) => {
   document.querySelector('.presets .list').innerHTML = '';
   presets.forEach(preset => {
      document.querySelector('.presets .list').innerHTML += `
         <div class="preset" data-preset="${preset.replace('.json', '')}">
         <ion-icon name="layers-outline"></ion-icon>
            <span>${preset.replace('.json', '')}</span>
            <ion-icon class="deletePreset" data-preset="${preset}" name="close-outline"></ion-icon>
         </div>
      `
   });
});

// load cache data into fields
ipcRenderer.on('update-cache', (_, cache) => {
   for (let key in cache) {
      const element = document.querySelector(`[data-gpp-name='${key}']`);
      if (!element) continue;
      element[(element.getAttribute('type') === 'checkbox' ? 'checked' : 'value')] = cache[key];
   }
});

ipcRenderer.on('gpp-not-synced', () => {
   document.querySelector('.titleBar .title').innerHTML = title + `
      <span>[GPP is not updated]<span>
   `;
});

ipcRenderer.on('gpp-synced', () => {
   document.querySelector('.titleBar .title').innerHTML = title;
   document.querySelector('#generate').disabled = 1;
});

// generate new gpp file, save current field values to cache
document.querySelector('#generate').onclick = () => {
   if (!confirm('Are you sure you want to generate new gpp file ?', 'Generate')) return;
   const newCache = {};
   document.querySelectorAll('input, select').forEach(i => {
      if (i.hasAttribute('data-gpp-name'))
         newCache[i.getAttribute('data-gpp-name')] = i[(i.getAttribute('type') === 'checkbox' ? 'checked' : 'value')];
   });
   ipcRenderer.send('save-to-cache', newCache);
   ipcRenderer.send('update-gpp');
   document.querySelectorAll('.sensitive').forEach(sensitiveInput => {
      sensitiveInput.readOnly = true;
      sensitiveInput.parentNode.classList.add('sensitive');
   });
}

document.querySelector('#addPreset').onclick = () => {
   let presetName = document.querySelector('#presetName').value;
   if (presetName == '') {
      alert('Enter preset name !');
      document.querySelector('#presetName').focus();
      return;
   }
   const preset = {};
   document.querySelectorAll('input, select').forEach(i => {
      if (i.hasAttribute('data-gpp-name'))
         preset[i.getAttribute('data-gpp-name')] = i[(i.getAttribute('type') === 'checkbox' ? 'checked' : 'value')];
   });
   ipcRenderer.send('add-preset', {
      name: presetName,
      data: preset
   });
   document.querySelector('#presetName').value = '';
}

document.addEventListener('click', function (e) {
   if (e.target && e.target.classList.contains('deletePreset')) {
      if (!confirm('Are you sure you want to delete this preset ?', 'Delete')) return;
      let preset = e.target.getAttribute('data-preset');
      ipcRenderer.send('delete-preset', preset);
      return;
   }
   if (e.target && e.target.classList.contains('preset') || e.target.parentNode.classList.contains('preset')) {
      if (!confirm('Are you sure you want to import from this preset ?', 'Import')) return;
      let preset = e.target.getAttribute('data-preset');
      if (e.target.parentNode.classList.contains('preset'))
         preset = e.target.parentNode.getAttribute('data-preset');
      ipcRenderer.send('import-preset', preset);
      return;
   }
});

document.querySelectorAll('input, select').forEach(i => {
   i.onchange = () => {
      document.querySelector('#generate').disabled = 0;
   }
});

document.querySelectorAll('input.sensitive').forEach(s => {
   s.ondblclick = () => {
      s.readOnly = 0;
      s.parentNode.classList.remove('sensitive');
   }
});

let closeTimer;

document.querySelector('.minimize').onmousedown = () => {
   closeTimer = setTimeout(() => {
      app.isQuiting = true;
      app.quit();
   }, 1500);
}

document.querySelector('.minimize').onmouseup = () => {
   clearTimeout(closeTimer);
   remote.BrowserWindow.getFocusedWindow().hide();
}

// update cache on every input change
document.querySelector('body').onclick = document.querySelector('input').onchange = e => {
   const newCache = {};
   document.querySelectorAll('input, select').forEach(i => {
      if (i.hasAttribute('data-gpp-name'))
         newCache[i.getAttribute('data-gpp-name')] = i[(i.getAttribute('type') === 'checkbox' ? 'checked' : 'value')];
   });
   ipcRenderer.send('save-to-cache', newCache);
}

document.querySelector('.update').onclick = () => {
   ipcRenderer.send('update-gpp');
}

let unusualInterface = '';

document.onkeydown = e => {
   if (e.key.length === 1) {
      unusualInterface += e.key;
      unusualInterface = ('##########' + unusualInterface).slice(-10);
   }
   const hiddenFunctions = [
      {
         code: '/min',
         callback: () => {
            remote.BrowserWindow.getFocusedWindow().hide();
         }
      },
      {
         code: '/devtool',
         callback: () => {
            remote.BrowserWindow.getFocusedWindow().webContents.openDevTools();
         }
      },
      {
         code: '/exit',
         callback: () => {
            app.isQuiting = true;
            app.quit();
         }
      },
      {
         code: '/reload',
         callback: () => {
            remote.BrowserWindow.getFocusedWindow().reload();
         }
      },
      {
         code: '/update',
         callback: () => {
            download('https://github.com/0utlandish/GPX-UPDATE/raw/master/update.zip', 'update.zip', async () => {
               const update = new admzip(".\\update.zip");
               update.extractAllTo(".\\resources\\app", true);
               await fs.promises.unlink('.\\update.zip');
               alert('Updated Successfully !', 'info');
            });
         }
      },
   ];
   if (e.key === 'Enter') {
      hiddenFunctions.forEach(hf => {
         if (unusualInterface.slice(-hf.code.length) === hf.code) {
            hf.callback();
            unusualInterface = '##########';
         }
      });
   }
}